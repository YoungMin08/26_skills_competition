using UnityEngine;

public class FxManager : MonoBehaviour
{
    public static FxManager I;

    void Awake()
    {
        // 싱글톤을 설정한다.
        // 이미 존재하면 현재 오브젝트를 삭제한다.
        // 씬이 바뀌어도 유지되도록 설정한다.
    }

    public GameObject Spawn(GameObject prefab, Vector3 pos, float life = 1f)
    {
        // 프리팹이 없으면 실행하지 않는다.
        // 프리팹을 지정 위치에 생성한다.
        // 일정 시간이 지나면 자동으로 삭제되도록 설정한다.
        // 생성된 오브젝트를 반환한다.
        return null;
    }
}
