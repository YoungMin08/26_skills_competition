using UnityEngine;

public class CameraShakeManager : MonoBehaviour
{
    public static CameraShakeManager I;

    Vector3 oriPos;
    float t;
    float power;

    void Awake()
    {
        // 싱글톤을 설정한다.
        // 이미 존재하면 현재 오브젝트를 삭제한다.
    }

    void Update()
    {
        // 흔들림 시간이 남아 있으면 감소시킨다.
        // 시간이 남아 있으면 랜덤 위치로 카메라를 흔든다.
        // 시간이 끝나면 카메라를 원래 위치로 되돌린다.
    }

    public void Shake(float p, float time)
    {
        // 현재 카메라 위치를 저장한다.
        // 흔들림 세기를 설정한다.
        // 흔들림 시간을 설정한다.
    }
}
