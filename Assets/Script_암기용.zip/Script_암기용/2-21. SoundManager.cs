using UnityEngine;

public class SoundManager : MonoBehaviour
{
    public static SoundManager I;

    public AudioSource bgm;
    public AudioSource sfx;

    void Awake()
    {
        // 싱글톤을 설정한다.
        // 이미 존재하면 현재 오브젝트를 삭제한다.
        // 씬이 바뀌어도 유지되도록 설정한다.
    }

    public void Bgm(AudioClip clip)
    {
        // 재생할 클립이 없으면 실행하지 않는다.
        // 이미 같은 BGM이 재생 중이면 다시 실행하지 않는다.
        // 새로운 클립을 설정한다.
        // 반복 재생을 설정한다.
        // BGM을 재생한다.
    }

    public void StopBgm()
    {
        // 현재 재생 중인 BGM을 정지한다.
    }

    public void Sfx(AudioClip clip)
    {
        // 재생할 클립이 없으면 실행하지 않는다.
        // 효과음을 한 번 재생한다.
    }
}
